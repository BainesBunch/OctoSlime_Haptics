
#ifndef _ESP_MILLIS_H
#define _ESP_MILLIS_H

#include <stdint.h>

uint32_t millis(void);

#endif // __ESP_MILLIS_H