/* sys/ctype.h - PROGMEM ctype handlers */

#ifndef _SYS_CTYPE_H_
#define _SYS_CTYPE_H_

// Will cause pgm_read_byte to be defined and be used by ctype macros
#include <sys/pgmspace.h>

#endif
