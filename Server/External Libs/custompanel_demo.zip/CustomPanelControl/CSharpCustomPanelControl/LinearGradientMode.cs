using System;
namespace CSharpCustomPanelControl
{
	public enum LinearGradientMode
	{
		Horizontal = 0,
		Vertical = 1,
		ForwardDiagonal = 2,
		BackwardDiagonal = 3,
		None = 4
	}
}
